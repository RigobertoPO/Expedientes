﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UNACH.Expedientes.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            Models.Usuario usuario = new Models.Usuario();
            usuario.Id = Guid.NewGuid();
            usuario.Correo = "dalexdiaz7@hotmail.com";
            usuario.password = "123456";
            usuario.Rol = "Administrador";
            return View(usuario);
        }
    }
}